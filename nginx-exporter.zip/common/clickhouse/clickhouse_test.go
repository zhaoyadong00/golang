package clickhouse

import (
	"exporter/models"
	"testing"
	"time"
)

func TestInitClickHouse(t *testing.T) {
	err := InitClickHouse("tcp://180.101.193.164:9090?username=&password=&database=logs&read_timeout=10&write_timeout=20&debug=true")
	if err != nil {
		t.Log(err)
		t.Failed()
	}
	var d = &models.Logs{
		Edate: time.Now(),
		EventId: 52,
		Channel: "sss",
		Event: "",
		N1: 123,
		N2: 234,
		N3: 345,
		N4: 456,
		N5: 456,
		N6: 456,
		F1: 456,
		F2: 456,
		F3: 456,
		B1: 456,
		B2: 456,
		B3: 456,
		V1: "aaa",
		V2: "aaa",
		V3: "aaa",
		V4: "aaa",
		V5: "aaa",
		V6: "aaa",
		V7: "aaa",
		V8: "aaa",
		V9: "aaa",
		S1: "aaa",
		S2: "aaa",
		S3: "aaa",
		S4: "aaa",
		S5: "aaa",
		S6: "aaa",
		T1: "aaa",
		T2: "aaa",
		T3: "aaa",
		E1: "aaa",
		E2: "aaa",
		E3: "aaa",
		E4: "aaa",
		E5: "aaa",
		E6: "aaa",
		LogTime: 161000852,
	}
	data := make([]*models.Logs , 0)
	for i := 0 ; i < 1000 ; i ++ {
		data = append(data, d)
	}
	for i := 0 ; i < 2 ; i++ {
		err = BetchInsert(data)
		if err != nil {
			t.Log("aa" , err)
			t.Failed()
		}
	}

}