package clickhouse

import (
	"database/sql"
	"errors"
	"exporter/models"
	"fmt"
	"github.com/ClickHouse/clickhouse-go"
	"log"
	"time"
)
var mapClickHouseConn map[string]*sql.DB = make(map[string]*sql.DB)

func InitClickHouse(tcp string) error {
	conn, err := sql.Open("clickhouse", tcp)
	if err != nil {
		log.Fatal("sql open err:" , err)
	}
	if err := conn.Ping(); err != nil {
		if exception, ok := err.(*clickhouse.Exception); ok {
			fmt.Printf("[%d] %s \n%s\n", exception.Code, exception.Message, exception.StackTrace)
		} else {
			fmt.Println("ping:" , err)
		}
		return err
	}
	SetClickHouse("default" , conn)
	var ping = func() {
		GetClickHouse().Ping()
	}
	go func() {
		t1 := time.NewTicker(60 * time.Second)
		select {
		case <-t1.C:
			ping()
		}
	}()
	return nil
}

func SetClickHouse(key string , e *sql.DB){
	mapClickHouseConn[key] = e
}

func GetClickHouse(keys ...string)(e *sql.DB){
	if len(keys)==0{
		return mapClickHouseConn["default"]
	}else{
		return mapClickHouseConn[keys[0]]
	}
}
func BetchRunLogs(datas []*models.RunLogs) error {
	if len(datas) <= 0 {
		return errors.New("datas is empty")
	}
	clickConn := GetClickHouse()
	tx , err := clickConn.Begin()
	if err != nil {
		return err
	}
	stmt, err := tx.Prepare("INSERT INTO run_logs (e_date,channel,project,event_id,event,path,request_id,uid,uuid,domain,method,level,get_params,post_params,header_params,form_params,response,message,user_agent,start_time,request_time,client_ver,os_name,os_ver,remote_ip,create_time) VALUES('','','',0,'','','','','','','','','','','','','','','','',0,'','','','',0)")
	defer stmt.Close()
	for i := 0; i < len(datas); i++ {
		if _, err := stmt.Exec(
			datas[i].EDate,
			datas[i].Channel,
			datas[i].Project,
			datas[i].EventId,
			datas[i].Event,
			datas[i].Path,
			datas[i].RequestId,
			datas[i].Uid,
			datas[i].Uuid,
			datas[i].Domain,
			datas[i].Method,
			datas[i].Level,
			datas[i].GetParams,
			datas[i].PostParams,
			datas[i].HeaderParams,
			datas[i].FormParams,
			datas[i].Response,
			datas[i].Message,
			datas[i].UserAgent,
			datas[i].StartTime,
			datas[i].RequestTime,
			datas[i].ClientVer,
			datas[i].OsName,
			datas[i].OsVer,
			datas[i].RemoteIp,
			datas[i].CreateTime,
		); err != nil {
			log.Println("stmt.Exec error:" , err)
		}
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	return nil
}
func BetchInsert(data []*models.Logs) error {
	if len(data) <= 0 {
		return errors.New("aaa")
	}
	clickConn := GetClickHouse()
	tx , err := clickConn.Begin()
	if err != nil {
		return err
	}
	stmt, err := tx.Prepare("INSERT INTO jiguang_mobile_game_booster (Edate, channel, Title, event_id, event, n1, n2, n3, n4, n5, n6, f1, f2, f3, b1, b2, b3, v1, v2, v3, v4, v5, v6, v7, v8, v9, s1, s2, s3, s4, s5, s6, t1, t2, t3, e1, e2, e3, e4, e5, e6, user_agent, client_id, client_ver, os_name, os_ver, client_ip, log_time) VALUES('', '', '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0)")
	defer stmt.Close()
	for i := 0; i < len(data); i++ {
		if _, err := stmt.Exec(
			data[i].Edate,
			data[i].Channel,
			data[i].Title,
			data[i].EventId,
			data[i].Event,
			data[i].N1,
			data[i].N2,
			data[i].N3,
			data[i].N4,
			data[i].N5,
			data[i].N6,
			data[i].F1,
			data[i].F2,
			data[i].F3,
			data[i].B1,
			data[i].B2,
			data[i].B3,
			data[i].V1,
			data[i].V2,
			data[i].V3,
			data[i].V4,
			data[i].V5,
			data[i].V6,
			data[i].V7,
			data[i].V8,
			data[i].V9,
			data[i].S1,
			data[i].S2,
			data[i].S3,
			data[i].S4,
			data[i].S5,
			data[i].S6,
			data[i].T1,
			data[i].T2,
			data[i].T3,
			data[i].E1,
			data[i].E2,
			data[i].E3,
			data[i].E4,
			data[i].E5,
			data[i].E6,
			data[i].UserAgent,
			data[i].ClientId,
			data[i].ClientVer,
			data[i].OsName,
			data[i].OsVer,
			data[i].ClientIp,
			data[i].LogTime,
		); err != nil {
			log.Fatal(err)
		}
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	return nil
}