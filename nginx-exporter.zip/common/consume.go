package common

import (
	"fmt"
	"github.com/streadway/amqp"
)

type Consume struct {
	conn    *amqp.Connection
	channel *amqp.Channel
	done    chan error
	exchange string
	exchangeType string
	queue amqp.Queue
	queueName string
	key string
}

func NewConsume(amqpURI, exchange, exchangeType, queueName, key string) (*Consume , error) {
	c := &Consume{
		conn: nil,
		channel: nil,
		done: make(chan error),
		exchange: exchange,
		exchangeType: exchangeType,
		queueName: queueName,
		key: key,
	}
	var err error
	//dial
	c.conn , err = amqp.Dial(amqpURI)
	if err != nil {
		return nil , fmt.Errorf("Dial: %s", err)
	}

	return c , nil
}

func (c *Consume)InitExchange() (*Consume , error){
	var err error
	c.channel, err = c.conn.Channel()
	if err != nil {
		return nil, fmt.Errorf("Channel: s%", err)
	}

	if err = c.channel.ExchangeDeclare(
		c.exchange,     //exchange name
		c.exchangeType, //exchange type
		true,           // durable
		false,          // delete when complete
		false,          // internal
		false,          // noWait
		nil,            // arguments
	); err != nil {
		return nil, fmt.Errorf("Exchange Declare: %s", err)
	}
	return c , nil
}
func (c *Consume)InitChannel() (*Consume , error) {
	var err error
	c.queue, err = c.channel.QueueDeclare(
		c.queueName, // name of the queue
		true,        // durable
		false,       // delete when unused
		false,       // exclusive
		false,       // noWait
		nil,         // arguments
	)
	if err != nil {
		return nil, fmt.Errorf("Queue Declare: %s", err)
	}
	if err = c.channel.QueueBind(
		c.queue.Name, // name of the queue
		c.key,      // bindingKey
		c.exchange, // sourceExchange
		false,      // noWait
		nil,        // arguments
	); err != nil {
		return nil, fmt.Errorf("Queue Bind: %s", err)
	}
	return c , nil
}
func (c *Consume)Consume(callback func(data []byte)bool){

	deliveries, _ := c.channel.Consume(
		c.queue.Name, // name
		"",      // consumerTag,
		false,      // noAck
		false,      // exclusive
		false,      // noLocal
		false,      // noWait
		nil,        // arguments
	)
	for d := range deliveries {
		res := callback(d.Body)
		if res {
			d.Ack(false)
		}
	}
}
