package common

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"encoding/json"
	"exporter/common/clickhouse"
	"exporter/common/protocol"
	"exporter/conf"
	"exporter/models"
	"log"
	"net"
	"strconv"
	"strings"
	"time"
)

//定时批量写入数据
func InsertData()  {
	interval , _ := strconv.Atoi(conf.Config["app"]["run_interval"])
	write_number , _ := strconv.Atoi(conf.Config["app"]["write_number"])//定义最大批量写入数据
	write_time , _ := strconv.Atoi(conf.Config["app"]["write_time"]) //当数据量小于 < write_number write_time 秒写入一次
	for {
		if len(conf.LogsData.Datas) < write_number && time.Now().Sub(conf.InTime) < time.Duration(int64(write_time)) * time.Second {//数据小于100条 5分钟写入一次
			time.Sleep(time.Second)//防止过度continue 造成CPU浪费
			continue
		}
		conf.LogsData.Lock()
		err := clickhouse.BetchRunLogs(conf.LogsData.Datas)
		if err != nil {
			//log.Println("clickhouse.BetchInsert error:" , err)
		}
		//写入后清空切片
		conf.LogsData.Datas = conf.LogsData.Datas[0:0]
		conf.LogsData.Unlock()
		conf.InTime = time.Now()
		time.Sleep(time.Duration(interval) * time.Second)
	}
}

//处理请求链接
func HandleConnection(conn net.Conn)  {
	scanner := bufio.NewScanner(conn)
	scanner.Split(func(data []byte, atEOF bool) (advance int, token []byte, err error) {
		if !atEOF && data[0] == 'V' {
			if len(data) > 4 {
				length := int16(0)
				binary.Read(bytes.NewReader(data[2:4]), binary.BigEndian, &length)
				if int(length) + 4 <= len(data) {
					return int(length) + 4, data[:int(length) + 4], nil
				}
			}
		}
		if atEOF {//如果接到 客户端关闭的消息 则关闭 否则 不设超时
			conn.Close()
		}
		return
	})
	//write_timeout , _ := strconv.Atoi(conf.Config["app"]["write_timeout"])//TCP 写入超时时间
	//read_timeout , _ := strconv.Atoi(conf.Config["app"]["read_timeout"])//TCP 读取超时时间
	//// 为了验证超时, 在循环外设置, 2秒超时
	//conn.SetWriteDeadline(time.Now().Add(time.Second * time.Duration(write_timeout)))
	//conn.SetReadDeadline(time.Now().Add(time.Second * time.Duration(read_timeout)))

	for scanner.Scan(){
		scannedPack := new(protocol.Package)
		err := scannedPack.Unpack(bytes.NewReader(scanner.Bytes()))
		if err != nil {
			log.Println("scannedPack.Unpack error:" , err)
		}
		if strings.ToLower(string(scannedPack.Version[:])) == "v1" {//目前只支持v1版本
			var data *models.RunLogs
			err := json.Unmarshal(scannedPack.Msg , &data)
			if err != nil {
				log.Println("json.Unmarshal error:" , err)
			}
			conf.LogsData.Lock()
			conf.LogsData.Datas = append(conf.LogsData.Datas, data)
			conf.LogsData.Unlock()
		}
		_  , err = conn.Write([]byte("OK"))
		if err != nil {
			log.Println("server conn.Write error:" , err)
		}

	}
	if scanner.Err() != nil {
		log.Println("数据格式错误。" , scanner.Err())
	}

}