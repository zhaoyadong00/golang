package common

import (
	"fmt"
	"github.com/streadway/amqp"
)

type Production struct {
	Conn    *amqp.Connection
	channel *amqp.Channel
	done    chan error
	exchange string
	exchangeType string
	queue amqp.Queue
	queueName string
	key string
}

func NewProduction(amqpURI, exchange, exchangeType, queueName, key string) (*Production , error) {
	p := &Production{
		Conn: nil,
		channel: nil,
		done: make(chan error),
		exchange: exchange,
		exchangeType: exchangeType,
		queueName: queueName,
		key: key,
	}
	var err error
	//dial
	p.Conn , err = amqp.Dial(amqpURI)
	if err != nil {
		return nil , fmt.Errorf("Dial: %s", err)
	}

	return p , nil
}

func (p *Production)InitExchange() (*Production , error){
	var err error
	p.channel, err = p.Conn.Channel()
	if err != nil {
		return nil, fmt.Errorf("Channel: s%", err)
	}

	if err = p.channel.ExchangeDeclare(
		p.exchange,     //exchange name
		p.exchangeType, //exchange type
		true,           // durable
		false,          // delete when complete
		false,          // internal
		false,          // noWait
		nil,            // arguments
	); err != nil {
		return nil, fmt.Errorf("Exchange Declare: %s", err)
	}
	return p , nil
}
func (p *Production)InitChannel() (*Production , error) {
	var err error
	p.queue, err = p.channel.QueueDeclare(
		p.queueName, // name of the queue
		true,        // durable
		false,       // delete when unused
		false,       // exclusive
		false,       // noWait
		nil,         // arguments
	)
	if err != nil {
		return nil, fmt.Errorf("Queue Declare: %s", err)
	}
	if err = p.channel.QueueBind(
		p.queue.Name, // name of the queue
		p.key,      // bindingKey
		p.exchange, // sourceExchange
		false,      // noWait
		nil,        // arguments
	); err != nil {
		return nil, fmt.Errorf("Queue Bind: %s", err)
	}
	return p , nil
}
func (p *Production)Publish(body string) error {
	var err error
	//if err = p.channel.Confirm(false); err != nil{
	//	return fmt.Errorf("Channel could not be put into confirm mode: %s", err)
	//}
	//confirm := p.channel.NotifyPublish(make(chan amqp.Confirmation, 1))
	//defer func(confirm  chan amqp.Confirmation) {
	//	if confirmed := <-confirm; confirmed.Ack {
	//		log.Printf("confirmed delivery with delivery tag: %d", confirmed.DeliveryTag)
	//	}
	//}(confirm)

	if err = p.channel.Publish(
		p.exchange,   // publish to an exchange
		p.key, // routing to 0 or more queues
		false,      // mandatory
		false,      // immediate
		amqp.Publishing{
			Headers:         amqp.Table{},
			ContentType:     "text/plain",
			ContentEncoding: "",
			Body:            []byte(body),
			DeliveryMode:    amqp.Transient, // 1=non-persistent, 2=persistent
			Priority:        0,              // 0-9
			// a bunch of application/implementation-specific fields
		},
	); err != nil {
		return fmt.Errorf("Exchange Publish: %s", err)
	}
	return nil
}
