package common

import (
	"fmt"
	"github.com/go-xorm/xorm"
	"strconv"
)

var mapXormEngin map[string]*xorm.Engine = make( map[string]*xorm.Engine)

func InitEngin(myCon map[string]string){
	e, err := xorm.NewEngine(myCon["type"], myCon["user"] + ":" + myCon["pwd"]+ "@tcp(" + myCon["host"]+ ":" + myCon["port"] + ")/" + myCon["db_name"] + "?charset=" + myCon["charset"])
	if err != nil {
		fmt.Println("data source init error", err.Error())
		return
	}
	e.SetMaxIdleConns(200)
	e.SetMaxOpenConns(1000)
	showSql , _ := strconv.ParseBool(myCon["is_show_sql"])
	e.ShowSQL(showSql)
	SetEngin("default" , e)
}

func SetEngin(key string,e *xorm.Engine){
	mapXormEngin[key] = e
}
func GetEngin(keys ...string)(e *xorm.Engine){
	if len(keys)==0{
		return mapXormEngin["default"]
	}else{
		return mapXormEngin[keys[0]]
	}
}
