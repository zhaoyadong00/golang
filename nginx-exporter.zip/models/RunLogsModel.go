package models

import (
	"sync"
	"time"
)
type RunLogsM struct {
	Datas []*RunLogs
	sync.Mutex
}
type RunLogs struct {
	EDate time.Time `json:"e_date"`
	Channel string `json:"channel"`
	Project string `json:"project"`
	EventId int64 `json:"event_id"`
	Event string `json:"event"`
	Path string `json:"path"`
	RequestId string `json:"request_id"`
	Uid string `json:"uid"`
	Uuid string `json:"uuid"`
	Domain string `json:"domain"`
	Method string `json:"method"`
	Level string `json:"level"`
	GetParams string `json:"get_params"`
	PostParams string `json:"post_params"`
	HeaderParams string `json:"header_params"`
	FormParams string `json:"form_params"`
	Response string `json:"response"`
	Message string `json:"message"`
	UserAgent string `json:"user_agent"`
	StartTime time.Time `json:"start_time"`
	RequestTime int64 `json:"request_time"`
	ClientVer string `json:"client_ver"`
	OsName string `json:"os_name"`
	OsVer string `json:"os_ver"`
	RemoteIp string `json:"remote_ip"`
	CreateTime time.Time `json:"create_time"`
}