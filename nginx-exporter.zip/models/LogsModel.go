package models

import (
	"sync"
	"time"
)
type LogsM struct {
	Datas []*Logs
	sync.Mutex
}
type Logs struct {
	Edate time.Time
	Channel string
	Title string
	EventId int64
	Event string
	N1 uint32
	N2 uint32
	N3 uint32
	N4 uint32
	N5 uint32
	N6 uint32
	F1 float64
	F2 float64
	F3 float64
	B1 int64
	B2 int64
	B3 int64
	V1 string
	V2 string
	V3 string
	V4 string
	V5 string
	V6 string
	V7 string
	V8 string
	V9 string
	S1 string
	S2 string
	S3 string
	S4 string
	S5 string
	S6 string
	T1 string
	T2 string
	T3 string
	E1 string
	E2 string
	E3 string
	E4 string
	E5 string
	E6 string
	UserAgent string
	ClientId string
	ClientVer string
	OsName string
	OsVer string
	ClientIp string
	LogTime uint32
}
