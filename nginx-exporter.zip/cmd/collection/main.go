package main

import (
	"encoding/json"
	"exporter/common"
	"exporter/conf"
	"flag"
	"github.com/satyrius/gonx"
	"io"
	"io/ioutil"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

//nginx-exporter config path
var path string

var endline = 0

func init()  {
	flag.StringVar(&path, "conf", "D:\\Go\\nginx-exporter\\conf\\config.json", "../conf/config.json")
}
//处理日志 写入队列
func main() {
	flag.Parse()
	confFile, err := os.Open(path)
	if err != nil {
		log.Println("Open config file err:" , err)
		return
	}
	by , err := ioutil.ReadAll(confFile)
	if err != nil {
		log.Println("Read config err:" , err)
		return
	}
	err = json.Unmarshal(by , &conf.Config)
	if err != nil {
		log.Println("Unmarshal json err:" , err)
		return
	}
	var con *common.Production
	con , err = common.NewProduction(conf.Config["rabbit"]["addr"], conf.Config["rabbit"]["exchange"], conf.Config["rabbit"]["exchange_type"], conf.Config["rabbit"]["queue"], conf.Config["rabbit"]["key"])
	defer con.Conn.Close()
	if err != nil {
		log.Println("NewConsume:" , err)
	}
	con , err = con.InitExchange()
	if err != nil {
		log.Println("InitExchange:" , err)
	}
	con , err = con.InitChannel()
	if err != nil {
		log.Println("InitChannel:" , err)
	}
	//启动NGINX-exporter 获取日志的最新行号 每 10秒钟运行一次 并记录最新的行号
	var nginxConfig io.Reader
	for {
		var logReader io.Reader
		file, err := os.Open(conf.Config["app"]["logpath"])
		if err != nil {
			panic(err)
		}
		logReader = file
		nginxConfig = strings.NewReader(`
            http {
                log_format   main  '`+ conf.Config["app"]["log_format"] +`';
            }
        `)
		reader, err := gonx.NewNginxReader(logReader, nginxConfig, "main")
		if err != nil {
			panic(err)
		}

		var i = 0
		var e = 0
		for {
			rec, err := reader.Read()
			if err == io.EOF {
				break
			} else if err != nil {
				panic(err)
			}

			uri , err := rec.Field("uri")
			if uri != "/favicon.ico"{
				query := rec.FieldsHash([]string{"query_string", "time_local","request_time","http_user_agent","remote_addr"})
				err := con.Publish(query)
				if err != nil {
					e++
				}else{
					i++
				}
			}
		}
		endline = i
		interval , _ := strconv.Atoi(conf.Config["app"]["run_interval"])
		log.Println("send success:" , i , "send fail:" , e)
		time.Sleep(time.Duration(interval) * time.Second)
		log.Println("Sleep time:" , interval , err)
	}

}
