package main

import (
	_ "database/sql"
	"encoding/json"
	"exporter/common"
	"exporter/common/clickhouse"
	"exporter/conf"
	"exporter/router"
	"flag"
	_ "github.com/ClickHouse/clickhouse-go"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	_ "net/http/pprof"
)

//nginx-exporter config path
var path string

//TCP 日志服务
func main() {
	flag.StringVar(&path, "C", "", "设置配置文件")
	flag.Parse()
	if path == "" {
		log.Println("请设置配置文件地址。")
		return
	}
	if err := initConf(); err != nil {
		return
	}
	go func() {
		http.ListenAndServe(":9999" , nil)
	}()
	err := clickhouse.InitClickHouse(conf.Config["clickhouse"]["tcp"])
	if err != nil {
		log.Println("clickhouse.InitClickHouse error:" , err)
		return
	}
	//开启 goroutine 处理内存数据
	go common.InsertData()
	//开启goroutine 支持http
	go listenHTTP()
	//开启goroutine 支持RedisMq
	go redisMq()
	//TCP长连接 推送日志
	listenTCP()
	return
}
func redisMq()  {
	
}
//启动TCP监听
func listenTCP()  {
	//TCP 长连接 用于接收远端push的数据
	ls , err := net.Listen("tcp" , conf.Config["app"]["port"])
	defer ls.Close()
	if err != nil {
		log.Println("Tcp listen error:" , err)
		return
	}
	for {
		conn , err := ls.Accept()
		if err != nil {
			log.Println("Tcp accept error:" , err)
			continue
		}
		go common.HandleConnection(conn)
	}
}
//启动HTTP接口形式
func listenHTTP() {
	en := router.InitRouter()
	var err error
	if conf.Config["app"]["tls_pem"] != "" {
		err = en.RunTLS(conf.Config["app"]["http_port"] , conf.Config["app"]["tls_pem"] , conf.Config["app"]["tls_key"])
	}else{
		err = en.Run(conf.Config["app"]["http_port"])
	}
	if err != nil {
		log.Println("listen http error:" , err)
	}
	return
}
//初始化config
func initConf() error {
	confFile, err := os.Open(path)
	if err != nil {
		log.Println("Open config file err:" , err)
		return err
	}
	by , err := ioutil.ReadAll(confFile)
	if err != nil {
		log.Println("Read config err:" , err)
		return err
	}
	err = json.Unmarshal(by , &conf.Config)
	if err != nil {
		log.Println("json.Unmarshal config error:" , err)
		return err
	}
	return nil
}

