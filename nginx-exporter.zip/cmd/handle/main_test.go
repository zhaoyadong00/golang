package main

import (
	"encoding/json"
	"exporter/common/protocol"
	"exporter/models"
	"log"
	"net"
	"testing"
	"time"
)

func TestData(t *testing.T)  {
	conn , err := net.Dial("tcp" , ":9091")
	defer conn.Close()
	if err != nil {
		log.Println("dial error:" , err)
		return
	}
	conn.SetDeadline(time.Now().Add(time.Second * 100))
	pack := &protocol.Package{
		Version:        [2]byte{'V', '1'},
		Timestamp:      time.Now().Unix(),
		HostnameLength: int16(len("test")),
		Hostname:       []byte("test"),
		TagLength:      4,
		Tag:            []byte("demo"),
		Msg:            []byte(""),
	}
	data := models.RunLogs{
		EDate: time.Now(),
		Channel: "ccc",
		Project: "test",
		EventId: 12,
		Event: "日志",
		Path: "/inde/api",
		RequestId: "123123",
		Uid: "1111",
		Uuid: "123123",
		Domain: "www.feihuo.com",
		Method: "GET",
		Level: "info",
		GetParams: "aaa",
		PostParams: "bbb",
		HeaderParams: "ccc",
		FormParams: "ddd",
		Response: "ttttttttttttt",
		Message: "yyyyyyyyyyyyyy",
		UserAgent: "chrome aaa",
		StartTime: time.Now(),
		RequestTime: time.Now().Unix(),
		ClientVer: "1.0.0",
		OsName: "windows 10",
		OsVer: "10.0.0",
		RemoteIp: "127.0.0.1",
		CreateTime: time.Now(),
	}
	by , err := json.Marshal(data)
	if err != nil {
		log.Println("aaa")
	}
	pack.Msg = by
	pack.Length = 8 + 2 + pack.HostnameLength + 2 + pack.TagLength + int16(len(pack.Msg))

	for i := 0 ; i < 10 ; i++ {
		pack.Pack(conn)
		var res = make([]byte , 2)
		conn.Read(res)
	}
	time.Sleep(10*time.Second)
	return
}
func BenchmarkInsertData(b *testing.B) {
	conn , err := net.Dial("tcp" , ":9091")
	defer conn.Close()
	if err != nil {
		log.Println("dial error:" , err)
		return
	}
	conn.SetDeadline(time.Now().Add(time.Second * 10))
	pack := &protocol.Package{
		Version:        [2]byte{'V', '1'},
		Timestamp:      time.Now().Unix(),
		HostnameLength: int16(len("test")),
		Hostname:       []byte("test"),
		TagLength:      4,
		Tag:            []byte("demo"),
		Msg:            []byte(""),
	}
	data := models.RunLogs{
		EDate: time.Now(),
		Channel: "ccc",
		Project: "test",
		EventId: 12,
		Event: "日志",
		Path: "/inde/api",
		RequestId: "123123",
		Uid: "1111",
		Uuid: "123123",
		Domain: "www.feihuo.com",
		Method: "GET",
		Level: "info",
		GetParams: "aaa",
		PostParams: "bbb",
		HeaderParams: "ccc",
		FormParams: "ddd",
		Response: "ttttttttttttt",
		Message: "yyyyyyyyyyyyyy",
		UserAgent: "chrome aaa",
		StartTime: time.Now(),
		RequestTime: time.Now().Unix(),
		ClientVer: "1.0.0",
		OsName: "windows 10",
		OsVer: "10.0.0",
		RemoteIp: "127.0.0.1",
		CreateTime: time.Now(),
	}
	by , err := json.Marshal(data)
	if err != nil {
		log.Println("aaa")
	}
	pack.Msg = by
	pack.Length = 8 + 2 + pack.HostnameLength + 2 + pack.TagLength + int16(len(pack.Msg))
	for i := 0 ; i < b.N ; i++ {
		pack.Pack(conn)
		var res = make([]byte , 2)
		conn.Read(res)
	}
}