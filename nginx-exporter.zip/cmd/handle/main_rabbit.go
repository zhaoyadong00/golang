package main
/*
import (
	_ "database/sql"
	"encoding/json"
	"exporter/common"
	"exporter/common/clickhouse"
	"exporter/conf"
	"exporter/models"
	"flag"
	_ "github.com/ClickHouse/clickhouse-go"
	"io/ioutil"
	"log"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

//nginx-exporter config path
var path string

func init()  {
	flag.StringVar(&path, "conf", "D:\\Go\\nginx-exporter\\conf\\config.json", "../conf/config.json")
	flag.Parse()
}
//消费队列数据
func main() {
	confFile, err := os.Open(path)
	if err != nil {
		log.Println("Open config file err:" , err)
		return
	}
	by , err := ioutil.ReadAll(confFile)
	if err != nil {
		log.Println("Read config err:" , err)
		return
	}
	err = json.Unmarshal(by , &conf.Config)
	clickhouse.InitClickHouse(conf.Config["clickhouse"]["tcp"])
	if err != nil {
		log.Println("Unmarshal json err:" , err)
		return
	}
	var consume *common.Consume
	consume , err = common.NewConsume(conf.Config["rabbit"]["addr"], conf.Config["rabbit"]["exchange"], conf.Config["rabbit"]["exchange_type"], conf.Config["rabbit"]["queue"], conf.Config["rabbit"]["key"])
	if err != nil {
		log.Println("Rabbit mq connect err:" , err)
		return
	}
	if err != nil {
		log.Println("NewConsume:" , err)
	}
	consume , err = consume.InitExchange()
	if err != nil {
		log.Println("InitExchange:" , err)
	}
	consume , err = consume.InitChannel()
	if err != nil {
		log.Println("InitChannel:" , err)
	}
	//var logsData = make([]*models.Logs , 0)
	var logsData = models.LogsM{}
	logsData.Datas = make([]*models.Logs , 0)
	var inData []string
	var jsonUnData interface{}
	go consume.Consume(func(data []byte) bool {
		inData = strings.Split(string(data) , ";")
		request , err := url.QueryUnescape(strings.Replace(inData[0] , "'query_string'=data=" , "" , 1))
		if err != nil {
			log.Println("url.QueryUnescape(strings.Replace(inData[0] , \"'query_string'=data=\" , \"\" , 1))")
			return true
		}
		if strings.Contains(request , "%3a%7b") {
			request , err = url.QueryUnescape(request)
			if err != nil {
				log.Println("strings.Contains(request , \"%3a%7b\")")
				return true
			}
		}
		err = json.Unmarshal([]byte(request) , &jsonUnData)
		if err != nil {
			log.Println("json.Unmarshal err:" , err)
		}
		reqTime , err := url.QueryUnescape(strings.Replace(inData[1] , "'time_local'=" , "" , 1))
		ti , err := time.Parse("02/Jan/2006:15:04:05 -0700", reqTime)
		http_user_agent , _ := url.QueryUnescape(strings.Replace(inData[3] , "'http_user_agent'=" , "" , 1))
		remote_addr , _ := url.QueryUnescape(strings.Replace(inData[4] , "'remote_addr'=" , "" , 1))
		event_id , _ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["event_id"]))
		n1 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n1"]))
		n2 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n2"]))
		n3 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n3"]))
		n4 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n4"]))
		n5 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n5"]))
		n6 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["n6"]))
		b1 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["b1"]))
		b2 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["b2"]))
		b3 ,_ := strconv.Atoi(Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["b3"]))
		tmp := &models.Logs{
			Edate: time.Now(),
			EventId: int64(event_id),
			Channel: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["channel"]),
			Event: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["event"]),
			N1: uint32(n1),
			N2: uint32(n2),
			N3: uint32(n3),
			N4: uint32(n4),
			N5: uint32(n5),
			N6: uint32(n6),
			F1: 456,
			F2: 456,
			F3: 456,
			B1: int64(b1),
			B2: int64(b2),
			B3: int64(b3),
			V1: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v1"]),
			V2: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v2"]),
			V3: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v3"]),
			V4: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v4"]),
			V5: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v5"]),
			V6: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v6"]),
			V7: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v7"]),
			V8: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v8"]),
			V9: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["v9"]),
			S1: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s1"]),
			S2: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s2"]),
			S3: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s3"]),
			S4: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s4"]),
			S5: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s5"]),
			S6: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["s6"]),
			T1: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["t1"]),
			T2: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["t2"]),
			T3: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["t3"]),
			E1: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e1"]),
			E2: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e2"]),
			E3: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e3"]),
			E4: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e4"]),
			E5: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e5"]),
			E6: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["e6"]),
			UserAgent:  http_user_agent,
			ClientId: remote_addr,
			ClientVer: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["client_ver"]),
			OsName: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["os_name"]),
			OsVer: Strval(jsonUnData.(map[string]interface{})["params"].(map[string]interface{})["os_ver"]),
			ClientIp: remote_addr,
			LogTime: uint32(ti.Unix()),
		}
		logsData.Lock()
		logsData.Datas = append(logsData.Datas, tmp)
		logsData.Unlock()
		return true
	})
	interval , _ := strconv.Atoi(conf.Config["app"]["run_interval"])
	for {
		logsData.Lock()
		err = clickhouse.BetchInsert(logsData.Datas)
		//写入后清空切片
		logsData.Datas = logsData.Datas[0:0]
		logsData.Unlock()
		time.Sleep(time.Duration(interval) * time.Second)
	}

}

// Strval 获取变量的字符串值
// 浮点型 3.0将会转换成字符串3, "3"
// 非数值或字符类型的变量将会被转换成JSON格式字符串
func Strval(value interface{}) string {
	// interface 转 string
	var key string
	if value == nil {
		return key
	}

	switch value.(type) {
	case float64:
		ft := value.(float64)
		key = strconv.FormatFloat(ft, 'f', -1, 64)
	case float32:
		ft := value.(float32)
		key = strconv.FormatFloat(float64(ft), 'f', -1, 64)
	case int:
		it := value.(int)
		key = strconv.Itoa(it)
	case uint:
		it := value.(uint)
		key = strconv.Itoa(int(it))
	case int8:
		it := value.(int8)
		key = strconv.Itoa(int(it))
	case uint8:
		it := value.(uint8)
		key = strconv.Itoa(int(it))
	case int16:
		it := value.(int16)
		key = strconv.Itoa(int(it))
	case uint16:
		it := value.(uint16)
		key = strconv.Itoa(int(it))
	case int32:
		it := value.(int32)
		key = strconv.Itoa(int(it))
	case uint32:
		it := value.(uint32)
		key = strconv.Itoa(int(it))
	case int64:
		it := value.(int64)
		key = strconv.FormatInt(it, 10)
	case uint64:
		it := value.(uint64)
		key = strconv.FormatUint(it, 10)
	case string:
		key = value.(string)
	case []byte:
		key = string(value.([]byte))
	default:
		newValue, _ := json.Marshal(value)
		key = string(newValue)
	}
	return key
}*/