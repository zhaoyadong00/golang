package router

import (
	"exporter/router/handler"
	"github.com/gin-gonic/gin"
)

func InitRouter() *gin.Engine {
	//gin 开启server
	en := gin.Default()
	//单条数据上报
	en.POST("/" , handler.PostOne)
	//批量多条上报
	en.POST("/datas" , handler.PostMultiple)
	en.GET("/" , handler.GetOne)
	en.GET("/datas" , handler.GetMultiple)
	return en
}