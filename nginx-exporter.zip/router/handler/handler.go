package handler

import (
	"encoding/json"
	"exporter/conf"
	"exporter/models"
	"github.com/gin-gonic/gin"
	"net/http"
)

func PostOne(c *gin.Context) {
	var req models.RunLogs
	err := c.BindJSON(&req)
	var resp gin.H
	if err != nil || req.EventId == 0{
		resp = gin.H{
			"status": "fail or event_id error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	conf.LogsData.Lock()
	conf.LogsData.Datas = append(conf.LogsData.Datas, &req)
	conf.LogsData.Unlock()
	resp = gin.H{
		"status": "OK",
	}
	c.JSON(http.StatusOK , resp)
}
//批量写入
func PostMultiple(c *gin.Context)  {
	var req []*models.RunLogs
	err := c.BindJSON(&req)
	var resp gin.H

	if err != nil{
		resp = gin.H{
			"status": "fail or event_id error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	conf.LogsData.Lock()
	conf.LogsData.Datas = append(conf.LogsData.Datas, req...)
	conf.LogsData.Unlock()
	resp = gin.H{
		"status": "OK",
	}
	c.JSON(http.StatusOK , resp)
}

func GetOne(c *gin.Context)  {
	var req models.RunLogs
	var resp gin.H
	data := c.DefaultQuery("data", "")
	if data == "" {
		resp = gin.H{
			"status": "params error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	err := json.Unmarshal([]byte(data) , &req)
	if err != nil || req.EventId == 0{
		resp = gin.H{
			"status": "fail or event_id error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	conf.LogsData.Lock()
	conf.LogsData.Datas = append(conf.LogsData.Datas, &req)
	conf.LogsData.Unlock()
	resp = gin.H{
		"status": "OK",
	}
	c.JSON(http.StatusOK , resp)
}

func GetMultiple(c *gin.Context)  {
	var req []*models.RunLogs
	var resp gin.H
	data := c.DefaultQuery("data", "")
	if data == "" {
		resp = gin.H{
			"status": "params error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	err := json.Unmarshal([]byte(data) , &req)
	if err != nil{
		resp = gin.H{
			"status": "fail or event_id error",
		}
		c.JSON(http.StatusOK , resp)
		return
	}
	conf.LogsData.Lock()
	conf.LogsData.Datas = append(conf.LogsData.Datas, req...)
	conf.LogsData.Unlock()
	resp = gin.H{
		"status": "OK",
	}
	c.JSON(http.StatusOK , resp)
}