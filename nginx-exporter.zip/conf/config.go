package conf

import (
	"exporter/models"
	"time"
)

//config 转为map
var Config = make(map[string]map[string]string , 1)

//全局变量
var LogsData = models.RunLogsM{
	Datas: make([]*models.RunLogs , 0 , 10000),
}
//上次写入时间 数据量小时固定时间写入
var InTime time.Time